import re

def extract_keywords(text):
    # Extract keywords by splitting and removing special characters
    return set(re.findall(r'\b\w+\b', text.lower()))

def calculate_ats_score(resume_path, job_description):
    # Read the uploaded resume
    '''with open(resume_path, 'r') as file:
        resume_text = file.read()'''
    # Open the file with explicit encoding
    with open(resume_path, 'r', encoding='utf-8', errors='ignore') as file:
        resume_text = file.read()


    # Extract keywords from both
    resume_keywords = extract_keywords(resume_text)
    job_keywords = extract_keywords(job_description)

    # Find matches and missing keywords
    matched_keywords = resume_keywords & job_keywords
    missing_keywords = job_keywords - resume_keywords

    # Calculate ATS score
    ats_score = (len(matched_keywords) / len(job_keywords)) * 100 if job_keywords else 0

    return round(ats_score, 2), list(missing_keywords)
