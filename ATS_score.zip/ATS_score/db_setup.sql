CREATE DATABASE resume_builder1;

USE resume_builder1;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(100)
);

CREATE TABLE resumes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    ats_score FLOAT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
