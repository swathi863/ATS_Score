from flask import Flask, render_template, request, redirect, url_for
import os
from utils.ats_score import calculate_ats_score
import pymysql

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Database connection
def get_db_connection():
    return pymysql.connect(host='localhost',
                           user='root',
                           password='22Kn1@0537',
                           database='resume_builder',
                           port=3306,
                           cursorclass=pymysql.cursors.DictCursor)

# Home route
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        name = request.form.get('name')
        return f"Hello, {name}! POST request received!"
    return render_template('index.html')
'''
@app.route('/')
def index():
    return render_template('index.html')
'''
# Upload Resume Route
@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        resume = request.files['resume']
        job_description = request.form['job_description']

        # Save uploaded resume
        resume_path = os.path.join(app.config['UPLOAD_FOLDER'], resume.filename)
        resume.save(resume_path)

        # Calculate ATS score
        ats_score, missing_keywords = calculate_ats_score(resume_path, job_description)

        # Render results
        return render_template('results.html', score=ats_score, missing=missing_keywords)

    return render_template('upload_resume.html')
'''
#to check database is connected or not
@app.route('/test-db', methods=['GET'])
def test_db():
    try:
        # Attempt to connect to the database
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute("SELECT DATABASE();")
        db_name = cursor.fetchone()
        connection.close()
        
        # Return a success response with the database name
        return {
            "success": True,
            "message": f"Connected to database: {db_name['DATABASE()']}"
        }, 200
    except Exception as e:
        # Return an error response if the connection fails
        return {
            "success": False,
            "error": str(e)
        }, 500

'''
if __name__ == '__main__':
    app.run(debug=True)
